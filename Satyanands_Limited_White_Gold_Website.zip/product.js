// Satyanand's Limited - Product Data
// Prices can be updated from admin.html without editing index.html.
const PRODUCTS = [
 {id:"gulab-jamun",name:"Gulab Jamun",description:"Traditional soft and sweet gulab jamun.",price:3.00,unit:"pc",category:"Sweets",active:true,image:""},
 {id:"ladoo",name:"Ladoo",description:"Traditional festive ladoo.",price:3.00,unit:"pc",category:"Sweets",active:true,image:""},
 {id:"milk-barfi",name:"Milk Barfi",description:"Rich and creamy milk barfi.",price:4.50,unit:"pc",category:"Sweets",active:true,image:""},
 {id:"hanuman-roat",name:"Hanuman Roat",description:"Available with banana or without banana.",price:8.00,unit:"pc",category:"Sweets",active:true,image:""},
 {id:"sweet-rice",name:"Sweet Rice",description:"Festive sweet rice.",price:0.00,unit:"16 oz container",category:"Sweets",active:true,image:""},
 {id:"flour-parsad",name:"Flour Parsad",description:"Fresh flour parsad.",price:150.00,unit:"lb",category:"Sweets",active:true,image:""},
 {id:"raksha-thread",name:"Plaited Raksha Thread",description:"Hand-plaited raksha thread for pujas and religious celebrations.",price:14.00,unit:"pc",category:"Raksha Thread",active:true,image:"assets/raksha-thread.png"}
];
const FREE_ITEMS=[
 {id:"fresh-flowers",name:"Fresh Flowers",price:0,unit:"free with order"},
 {id:"neem-leaf",name:"Neem Leaf",price:0,unit:"free with order"},
 {id:"bay-leaf",name:"Bay Leaf",price:0,unit:"free with order"}
];
const BUSINESS={name:"Satyanand's Limited",established:"Est 2024",phone:"8687870821",displayPhone:"(868) 787-0821",email:"satyanandslimitedest.24@yahoo.com",instagram:"Satyanand's Limited",vatRate:12.5};
if(typeof window!=="undefined"){window.SATYANANDS_PRODUCTS=PRODUCTS;window.SATYANANDS_FREE_ITEMS=FREE_ITEMS;window.SATYANANDS_BUSINESS=BUSINESS;}